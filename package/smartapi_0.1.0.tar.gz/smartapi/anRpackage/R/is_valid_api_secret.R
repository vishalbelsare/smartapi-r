is_valid_api_secret <-
function(object){
  if(!is_connection_obj(object))return(FALSE)
  return(length(object@api_secret) > 0)
}
